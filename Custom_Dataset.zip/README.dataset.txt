# Aircraft_Annotation > 2024-04-22 3:06pm
https://universe.roboflow.com/aircraftannotation/aircraft_annotation

Provided by a Roboflow user
License: CC BY 4.0

